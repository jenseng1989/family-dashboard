import "server-only";

import { supabase } from "@/lib/supabase";
import type { AppSettings, AppTabId } from "@/lib/app-settings-client";

const DEFAULT_SETTINGS: AppSettings = {
  defaultTab: "home",
  showAdminButton: true,
  dashboardName: "Family Dashboard",
  showResorTab: false,
  showHemmet3DTab: false,
};

const VALID_TABS: AppTabId[] = [
  "home",
  "weather",
  "family",
  "gothenburg",
  "fun",
  "resor",
  "hemmet3d",
];

type SettingsRow = {
  setting_key: string;
  setting_value: string;
};

function isValidTab(value: string): value is AppTabId {
  return VALID_TABS.includes(value as AppTabId);
}

function rowsToSettings(rows: SettingsRow[] | null): AppSettings {
  const settings: AppSettings = { ...DEFAULT_SETTINGS };

  for (const row of rows ?? []) {
    switch (row.setting_key) {
      case "default_tab":
        if (isValidTab(row.setting_value)) settings.defaultTab = row.setting_value;
        break;
      case "show_admin_button":
        settings.showAdminButton = row.setting_value === "true";
        break;
      case "dashboard_name":
        if (row.setting_value.trim()) settings.dashboardName = row.setting_value.trim();
        break;
      case "show_resor_tab":
        settings.showResorTab = row.setting_value === "true";
        break;
      case "show_hemmet3d_tab":
        settings.showHemmet3DTab = row.setting_value === "true";
        break;
    }
  }

  if (
    (settings.defaultTab === "resor" && !settings.showResorTab) ||
    (settings.defaultTab === "hemmet3d" && !settings.showHemmet3DTab)
  ) {
    settings.defaultTab = "home";
  }

  return settings;
}

export async function getInitialAppSettings(): Promise<AppSettings> {
  try {
    const { data, error } = await supabase
      .from("app_settings")
      .select("setting_key, setting_value");

    if (error) {
      console.error("Kunde inte läsa initiala appinställningar:", error);
      return { ...DEFAULT_SETTINGS };
    }

    return rowsToSettings(data);
  } catch (error) {
    console.error("Oväntat fel vid hämtning av initiala appinställningar:", error);
    return { ...DEFAULT_SETTINGS };
  }
}
