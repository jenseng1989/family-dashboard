import { createClient } from "@supabase/supabase-js";

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL;

const supabasePublishableKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseUrl) {
  throw new Error(
    "Miljövariabeln NEXT_PUBLIC_SUPABASE_URL saknas."
  );
}

if (!supabasePublishableKey) {
  throw new Error(
    "Miljövariabeln NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY saknas."
  );
}

export const supabase = createClient(
  supabaseUrl,
  supabasePublishableKey
);