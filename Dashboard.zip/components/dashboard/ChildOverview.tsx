"use client";

import {
  Baby,
  Cake,
  CalendarDays,
  LoaderCircle,
  RefreshCw,
  Sparkles,
} from "lucide-react";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  getFamilyMembersFromDatabase,
} from "@/lib/family-db";
import type {
  FamilyMember,
} from "@/lib/family";

function parseLocalDate(
  dateString: string
): Date {
  const [
    year,
    month,
    day,
  ] =
    dateString
      .split("-")
      .map(Number);

  return new Date(
    year,
    month - 1,
    day
  );
}

function startOfDay(
  date: Date
): Date {
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  );
}

function daysBetween(
  start: Date,
  end: Date
): number {
  const startUtc =
    Date.UTC(
      start.getFullYear(),
      start.getMonth(),
      start.getDate()
    );

  const endUtc =
    Date.UTC(
      end.getFullYear(),
      end.getMonth(),
      end.getDate()
    );

  return Math.round(
    (
      endUtc -
      startUtc
    ) /
      86_400_000
  );
}

function addMonthsClamped(
  date: Date,
  months: number
): Date {
  const target =
    new Date(
      date.getFullYear(),
      date.getMonth() +
        months,
      1
    );

  const lastDay =
    new Date(
      target.getFullYear(),
      target.getMonth() +
        1,
      0
    ).getDate();

  target.setDate(
    Math.min(
      date.getDate(),
      lastDay
    )
  );

  return target;
}

function getCalendarAge(
  birthdayString: string,
  referenceDate:
    Date = new Date()
): {
  years: number;
  months: number;
  days: number;
  totalDays: number;
} {
  const birthday =
    startOfDay(
      parseLocalDate(
        birthdayString
      )
    );

  const today =
    startOfDay(
      referenceDate
    );

  if (
    today <
    birthday
  ) {
    return {
      years: 0,
      months: 0,
      days: 0,
      totalDays: 0,
    };
  }

  let totalMonths =
    (
      today.getFullYear() -
      birthday.getFullYear()
    ) *
      12 +
    (
      today.getMonth() -
      birthday.getMonth()
    );

  let monthAnchor =
    addMonthsClamped(
      birthday,
      totalMonths
    );

  if (
    monthAnchor >
    today
  ) {
    totalMonths -= 1;

    monthAnchor =
      addMonthsClamped(
        birthday,
        totalMonths
      );
  }

  const years =
    Math.floor(
      totalMonths / 12
    );

  const months =
    totalMonths % 12;

  const days =
    daysBetween(
      monthAnchor,
      today
    );

  return {
    years,
    months,
    days,
    totalDays:
      daysBetween(
        birthday,
        today
      ),
  };
}

function getNextBirthday(
  birthdayString: string,
  referenceDate:
    Date = new Date()
): {
  date: Date;
  nextAge: number;
  daysUntil: number;
} {
  const birthday =
    parseLocalDate(
      birthdayString
    );

  const today =
    startOfDay(
      referenceDate
    );

  let nextBirthday =
    new Date(
      today.getFullYear(),
      birthday.getMonth(),
      birthday.getDate()
    );

  if (
    nextBirthday <
    today
  ) {
    nextBirthday =
      new Date(
        today.getFullYear() +
          1,
        birthday.getMonth(),
        birthday.getDate()
      );
  }

  const nextAge =
    nextBirthday.getFullYear() -
    birthday.getFullYear();

  return {
    date:
      nextBirthday,
    nextAge,
    daysUntil:
      daysBetween(
        today,
        nextBirthday
      ),
  };
}

function getAgeTitle(
  age: {
    years: number;
    months: number;
    days: number;
  }
): string {
  const parts:
    string[] = [];

  if (
    age.years > 0
  ) {
    parts.push(
      `${age.years} ${
        age.years === 1
          ? "år"
          : "år"
      }`
    );
  }

  if (
    age.months > 0 ||
    age.years === 0
  ) {
    parts.push(
      `${age.months} ${
        age.months === 1
          ? "månad"
          : "månader"
      }`
    );
  }

  parts.push(
    `${age.days} ${
      age.days === 1
        ? "dag"
        : "dagar"
    }`
  );

  return parts.join(
    " och "
  );
}

function getBirthdayCountdownText(
  displayName: string,
  nextAge: number,
  daysUntil: number
): string {
  if (
    daysUntil === 0
  ) {
    return `Idag fyller ${displayName} ${nextAge} år! 🎉`;
  }

  if (
    daysUntil === 1
  ) {
    return `Imorgon fyller ${displayName} ${nextAge} år`;
  }

  return `${daysUntil} dagar till ${nextAge}-årsdagen`;
}

type ChildOverviewProps = {
  memberId: string;
  displayName: string;
  emoji?: string;
};

export default function ChildOverview({
  memberId,
  displayName,
  emoji = "👶",
}: ChildOverviewProps) {
  const [
    person,
    setPerson,
  ] =
    useState<
      FamilyMember | null
    >(null);

  const [
    isLoading,
    setIsLoading,
  ] =
    useState(true);

  const [
    errorMessage,
    setErrorMessage,
  ] =
    useState<
      string | null
    >(null);

  const [
    now,
    setNow,
  ] =
    useState(
      () => new Date()
    );

  const fetchPerson = useCallback(() => {
    return getFamilyMembersFromDatabase()
      .then((members) => {
        const result = members.find((member) => member.id === memberId) ?? null;
        if (!result) {
          throw new Error(
            `${displayName} kunde inte hittas bland familjemedlemmarna.`,
          );
        }
        setPerson(result);
      })
      .catch((error) => {
        console.error(`Kunde inte hämta ${displayName}s uppgifter:`, error);

        setErrorMessage(`${displayName}s uppgifter kunde inte hämtas.`);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [memberId, displayName]);

  const loadPerson = useCallback(() => {
    setIsLoading(true);
    setErrorMessage(null);
    return fetchPerson();
  }, [fetchPerson]);

  const [previousFetchPersonKey, setPreviousFetchPersonKey] = useState(() => [
    memberId,
    displayName,
  ]);
  if (
    previousFetchPersonKey[0] !== memberId ||
    previousFetchPersonKey[1] !== displayName
  ) {
    setPreviousFetchPersonKey([memberId, displayName]);
    setIsLoading(true);
    setErrorMessage(null);
  }

  useEffect(() => {
    void fetchPerson();

    function handleFamilyDataChanged() {
      void loadPerson();
    }

    window.addEventListener(
      "family-data-changed",
      handleFamilyDataChanged
    );

    return () => {
      window.removeEventListener(
        "family-data-changed",
        handleFamilyDataChanged
      );
    };
  }, [fetchPerson, loadPerson]);

  useEffect(() => {
    const intervalId =
      window.setInterval(
        () => {
          setNow(
            new Date()
          );
        },
        60 * 60 * 1000
      );

    return () => {
      window.clearInterval(
        intervalId
      );
    };
  }, []);

  const age =
    useMemo(
      () =>
        person
          ? getCalendarAge(
              person.birthday,
              now
            )
          : null,
      [
        person,
        now,
      ]
    );

  const nextBirthday =
    useMemo(
      () =>
        person
          ? getNextBirthday(
              person.birthday,
              now
            )
          : null,
      [
        person,
        now,
      ]
    );

  if (isLoading) {
    return (
      <section className="relative overflow-hidden rounded-[2rem] border border-amber-300/15 bg-gradient-to-br from-slate-950 via-amber-950/35 to-rose-950/20 p-5 shadow-2xl sm:p-6 shadow-amber-950/20">
        <div className="flex min-h-44 flex-col items-center justify-center gap-3 sm:min-h-48">
          <LoaderCircle
            size={32}
            className="animate-spin text-amber-300"
          />

          <p className="text-sm text-slate-400">
            Hämtar {displayName}s uppgifter…
          </p>
        </div>
      </section>
    );
  }

  if (
    errorMessage ||
    !person ||
    !age ||
    !nextBirthday
  ) {
    return (
      <section className="rounded-[2rem] border border-red-300/15 bg-slate-950/70 p-5 sm:p-6">
        <div className="flex min-h-44 flex-col items-center justify-center text-center">
          <Baby
            size={36}
            className="text-rose-300"
          />

          <p className="mt-4 font-semibold text-white">
            {displayName} kunde inte laddas
          </p>

          <p className="mt-2 text-sm text-slate-400">
            {errorMessage}
          </p>

          <button
            type="button"
            onClick={() =>
              void loadPerson()
            }
            className="mt-5 flex items-center gap-2 rounded-xl bg-rose-500 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-rose-400"
          >
            <RefreshCw
              size={16}
            />

            Försök igen
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="relative overflow-hidden rounded-[2rem] border border-amber-300/15 bg-gradient-to-br from-slate-950 via-amber-950/35 to-rose-950/25 p-5 shadow-2xl shadow-amber-950/20 sm:p-6">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full bg-amber-400/10 blur-3xl" />
        <div className="absolute -bottom-28 -left-20 h-72 w-72 rounded-full bg-rose-400/[0.08] blur-3xl" />
      </div>

      <div className="relative">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-amber-200/20 bg-amber-400/10 text-3xl shadow-lg shadow-amber-950/20 sm:h-16 sm:w-16 sm:text-4xl">
              {person.emoji || emoji}
            </div>

            <div>
              <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-300">
                <Sparkles
                  size={15}
                />

                Familjen
              </p>

              <h2 className="mt-1 text-2xl font-black text-white sm:text-4xl">
                {displayName}
              </h2>

              <p className="mt-2 text-base font-semibold text-amber-100 sm:text-lg">
                {getAgeTitle(
                  age
                )}
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-rose-300/15 bg-rose-400/[0.06] px-3.5 py-3 sm:px-4 lg:min-w-64">
            <div className="flex items-center gap-2 text-rose-300">
              <Cake
                size={18}
              />

              <p className="text-xs font-semibold uppercase tracking-[0.15em]">
                Nästa födelsedag
              </p>
            </div>

            <p className="mt-2 font-bold text-white">
              {getBirthdayCountdownText(
                displayName,
                nextBirthday.nextAge,
                nextBirthday.daysUntil
              )}
            </p>

            <p className="mt-1 text-xs capitalize text-slate-500">
              {nextBirthday.date.toLocaleDateString(
                "sv-SE",
                {
                  weekday:
                    "long",
                  day:
                    "numeric",
                  month:
                    "long",
                  year:
                    "numeric",
                }
              )}
            </p>
          </div>
        </div>

        <div className="mt-5 grid gap-3 sm:mt-6 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/10 bg-slate-950/30 p-3.5 sm:p-4">
            <div className="flex items-center gap-2 text-amber-300">
              <CalendarDays
                size={17}
              />

              <p className="text-xs font-semibold uppercase tracking-[0.14em]">
                Dagar gammal
              </p>
            </div>

            <p className="mt-2 text-2xl font-bold text-white">
              {new Intl.NumberFormat(
                "sv-SE"
              ).format(
                age.totalDays
              )}
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-950/30 p-3.5 sm:p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-rose-300">
              Född
            </p>

            <p className="mt-2 text-lg font-bold capitalize text-white">
              {parseLocalDate(
                person.birthday
              ).toLocaleDateString(
                "sv-SE",
                {
                  day:
                    "numeric",
                  month:
                    "long",
                  year:
                    "numeric",
                }
              )}
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-950/30 p-3.5 sm:p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-violet-300">
              Nästa ålder
            </p>

            <p className="mt-2 text-2xl font-bold text-white">
              {nextBirthday.nextAge} år
            </p>

            <p className="mt-1 text-xs text-slate-500">
              om{" "}
              {nextBirthday.daysUntil}{" "}
              dagar
            </p>
          </div>
        </div>

        <p className="mt-4 border-t border-white/10 pt-3.5 text-xs text-slate-500 sm:mt-5 sm:pt-4">
          Födelsedatumet hämtas från familjedatabasen och uppdateras automatiskt om det ändras under Administrera personer.
        </p>
      </div>
    </section>
  );
}
