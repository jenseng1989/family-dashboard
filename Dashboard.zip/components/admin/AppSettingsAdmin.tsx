"use client";

import {
  ArrowLeft,
  Check,
  Eye,
  EyeOff,
  Home,
  LoaderCircle,
  RotateCcw,
  Save,
  Settings,
  School,
  Plane,
  HousePlus,
} from "lucide-react";
import Link from "next/link";
import {
  useCallback,
  useEffect,
  useState,
} from "react";

type TabId =
  | "home"
  | "weather"
  | "family"
  | "gothenburg"
  | "fun"
  | "resor"
  | "hemmet3d";

type AppSettings = {
  defaultTab: TabId;
  showAdminButton: boolean;
  dashboardName: string;
  schoolLunchUrl: string;
  showResorTab: boolean;
  showHemmet3DTab: boolean;
};

type ApiResponse = {
  settings?: AppSettings;
  error?: string;
};

const DEFAULT_SETTINGS: AppSettings = {
  defaultTab: "home",
  showAdminButton: true,
  dashboardName: "Family Dashboard",
  schoolLunchUrl: "",
  showResorTab: false,
  showHemmet3DTab: false,
};

const tabOptions: {
  id: TabId;
  label: string;
  description: string;
}[] = [
  {
    id: "home",
    label: "Start",
    description: "Dashboardens startsida.",
  },
  {
    id: "weather",
    label: "Väder",
    description: "Väderprognos, luftkvalitet och pollen.",
  },
  {
    id: "family",
    label: "Familjen",
    description: "Familjens gemensamma och personliga innehåll.",
  },
  {
    id: "gothenburg",
    label: "Göteborg",
    description: "Lokala funktioner för Göteborg.",
  },
  {
    id: "resor",
    label: "Resor",
    description: "Planering av familjens resor.",
  },
  {
    id: "hemmet3d",
    label: "Smarthem",
    description: "Rum och smarta enheter i 3D.",
  },
  {
    id: "fun",
    label: "Utforska",
    description: "Rymd, jord och andra utforskarfunktioner.",
  },
];

export default function AppSettingsAdmin() {
  const [settings, setSettings] =
    useState<AppSettings>(DEFAULT_SETTINGS);

  const [savedSettings, setSavedSettings] =
    useState<AppSettings>(DEFAULT_SETTINGS);

  const [isLoading, setIsLoading] =
    useState(true);

  const [isSaving, setIsSaving] =
    useState(false);

  const [error, setError] =
    useState<string | null>(null);

  const [successMessage, setSuccessMessage] =
    useState<string | null>(null);

  const fetchSettings = useCallback(() => {
    return fetch("/api/admin/app-settings", {
      method: "GET",
      cache: "no-store",
    })
      .then(async (response) => {
        const result = (await response.json()) as ApiResponse;
        if (!response.ok) {
          throw new Error(result.error ?? `API-fel ${response.status}`);
        }
        if (!result.settings) {
          throw new Error("API:t returnerade inga appinställningar.");
        }
        const loadedSettings = {
          ...DEFAULT_SETTINGS,
          ...result.settings,
        };
        setSettings(loadedSettings);
        setSavedSettings(loadedSettings);
      })
      .catch((err) => {
        console.error("Kunde inte läsa appinställningar:", err);

        setError(
          err instanceof Error
            ? err.message
            : "Appinställningarna kunde inte hämtas.",
        );
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);


  useEffect(() => {
    void fetchSettings();
  }, [fetchSettings]);

  const hasChanges =
    settings.defaultTab !== savedSettings.defaultTab ||
    settings.showAdminButton !==
      savedSettings.showAdminButton ||
    settings.dashboardName !==
      savedSettings.dashboardName ||
    settings.schoolLunchUrl !==
      savedSettings.schoolLunchUrl ||
    settings.showResorTab !== savedSettings.showResorTab ||
    settings.showHemmet3DTab !== savedSettings.showHemmet3DTab;

  async function saveSettings() {
    const dashboardName =
      settings.dashboardName.trim();

    if (!dashboardName) {
      setError(
        "Dashboardens namn får inte vara tomt."
      );
      return;
    }

    const schoolLunchUrl =
      settings.schoolLunchUrl.trim();

    if (schoolLunchUrl) {
      try {
        const parsedUrl = new URL(schoolLunchUrl);

        if (
          parsedUrl.protocol !== "https:" ||
          parsedUrl.hostname !== "skolmaten.se" ||
          !parsedUrl.pathname.startsWith("/api/4/rss/week/")
        ) {
          throw new Error();
        }
      } catch {
        setError(
          "Matsedelslänken måste vara en giltig Skolmaten RSS-länk."
        );
        return;
      }
    }

    if (!settings.showResorTab && settings.defaultTab === "resor") {
      setError("Aktivera Resor innan du väljer den som standardflik.");
      return;
    }

    if (!settings.showHemmet3DTab && settings.defaultTab === "hemmet3d") {
      setError("Aktivera Smarthem innan du väljer den som standardflik.");
      return;
    }

    setIsSaving(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch(
        "/api/admin/app-settings",
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ...settings,
            dashboardName,
            schoolLunchUrl,
          }),
        }
      );

      const result =
        (await response.json()) as ApiResponse & {
          success?: boolean;
        };

      if (!response.ok) {
        throw new Error(
          result.error ??
            `API-fel ${response.status}`
        );
      }

      const updatedSettings =
        result.settings ?? {
          ...settings,
          dashboardName,
          schoolLunchUrl,
        };

      setSettings(updatedSettings);
      setSavedSettings(updatedSettings);

      setSuccessMessage(
        "Appinställningarna har sparats."
      );
    } catch (err) {
      console.error(
        "Kunde inte spara appinställningar:",
        err
      );

      setError(
        err instanceof Error
          ? err.message
          : "Appinställningarna kunde inte sparas."
      );
    } finally {
      setIsSaving(false);
    }
  }

  function resetChanges() {
    setSettings(savedSettings);
    setError(null);
    setSuccessMessage(null);
  }

  if (isLoading) {
    return (
      <main className="min-h-screen bg-[#0a0a0a] text-[#ededed]">
        <div className="mx-auto flex min-h-screen w-full max-w-7xl items-center justify-center px-4">
          <div className="flex items-center gap-3 text-slate-300">
            <LoaderCircle
              size={22}
              className="animate-spin"
            />
            <span className="text-sm font-semibold">
              Hämtar appinställningar…
            </span>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#0a0a0a] text-[#ededed]">
      <div className="mx-auto w-full max-w-7xl px-4 py-5 sm:px-6 sm:py-6 lg:px-8">
        {/* HEADER */}
        <header className="rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:p-6">
          <Link
            href="/admin"
            className="inline-flex items-center gap-2 text-sm font-semibold text-slate-400 transition hover:text-white"
          >
            <ArrowLeft size={17} />
            Till Admin
          </Link>

          <div className="mt-4 flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-amber-300/15 bg-amber-400/[0.08] text-amber-200 sm:h-14 sm:w-14">
              <Settings size={28} />
            </div>

            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-400">
                Administration
              </p>

              <h1 className="mt-1 text-2xl font-bold text-white sm:text-3xl">
                Appinställningar
              </h1>

              <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
                Globala inställningar för hur Family Dashboard
                ska starta och bete sig.
              </p>
            </div>
          </div>
        </header>

        {/* DASHBOARD NAME */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <div className="flex items-start gap-3 sm:gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-slate-200 sm:h-11 sm:w-11">
              <Home size={21} />
            </div>

            <div className="min-w-0 flex-1">
              <h2 className="font-bold text-white">
                Dashboardnamn
              </h2>

              <p className="mt-1 text-sm leading-6 text-slate-400">
                Namnet som ska användas för familjens dashboard.
              </p>

              <div className="mt-4 max-w-xl">
                <label
                  htmlFor="dashboard-name"
                  className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500"
                >
                  Namn
                </label>

                <input
                  id="dashboard-name"
                  type="text"
                  maxLength={60}
                  value={settings.dashboardName}
                  onChange={(event) => {
                    setSettings((current) => ({
                      ...current,
                      dashboardName:
                        event.target.value,
                    }));

                    setSuccessMessage(null);
                  }}
                  className="min-h-12 w-full rounded-2xl border border-white/10 bg-slate-950/40 px-4 text-sm font-semibold text-white outline-none transition placeholder:text-slate-600 focus:border-blue-400/50 focus:ring-2 focus:ring-blue-500/20"
                  placeholder="Family Dashboard"
                />

                <p className="mt-2 text-xs text-slate-500">
                  {settings.dashboardName.length}/60 tecken
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* DEFAULT TAB */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <h2 className="font-bold text-white">
            Standardflik
          </h2>

          <p className="mt-1 text-sm leading-6 text-slate-400">
            Välj vilken huvudflik som ska visas när
            dashboarden öppnas.
          </p>

          <div className="mt-4 grid grid-cols-1 gap-2.5 sm:gap-3 md:grid-cols-2 xl:grid-cols-3">
            {tabOptions.filter((tab) => (tab.id !== "resor" || settings.showResorTab) && (tab.id !== "hemmet3d" || settings.showHemmet3DTab)).map((tab) => {
              const selected =
                settings.defaultTab === tab.id;

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setSettings((current) => ({
                      ...current,
                      defaultTab: tab.id,
                    }));

                    setSuccessMessage(null);
                  }}
                  className={[
                    "relative rounded-2xl border p-3.5 text-left transition sm:p-4",
                    selected
                      ? "border-blue-400/40 bg-blue-500/10"
                      : "border-white/10 bg-slate-950/25 hover:border-white/20 hover:bg-white/[0.06]",
                  ].join(" ")}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p
                        className={[
                          "font-semibold",
                          selected
                            ? "text-blue-200"
                            : "text-white",
                        ].join(" ")}
                      >
                        {tab.label}
                      </p>

                      <p className="mt-1 text-xs leading-5 text-slate-400">
                        {tab.description}
                      </p>
                    </div>

                    <div
                      className={[
                        "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border",
                        selected
                          ? "border-blue-400 bg-blue-500 text-white"
                          : "border-white/15 text-transparent",
                      ].join(" ")}
                    >
                      <Check size={14} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* RESOR */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3 sm:gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-500/15 text-blue-300">
                <Plane size={21} />
              </div>
              <div>
                <h2 className="font-bold text-white">Visa fliken Resor</h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
                  Aktivera eller dölj reseplaneringen i dashboardens huvudmeny.
                  Resor är dold som standard.
                </p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-label="Visa fliken Resor"
              aria-checked={settings.showResorTab}
              onClick={() => {
                setSettings((current) => ({
                  ...current,
                  showResorTab: !current.showResorTab,
                  defaultTab: current.showResorTab && current.defaultTab === "resor" ? "home" : current.defaultTab,
                }));
                setSuccessMessage(null);
              }}
              className={[
                "relative h-8 w-14 shrink-0 rounded-full border transition",
                settings.showResorTab
                  ? "border-blue-400/40 bg-blue-500"
                  : "border-white/10 bg-slate-700",
              ].join(" ")}
            >
              <span className={[
                "absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-transform",
                settings.showResorTab ? "translate-x-7" : "translate-x-1",
              ].join(" ")} />
            </button>
          </div>
        </section>

        {/* SMARTHEM */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3 sm:gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-500/15 text-blue-300">
                <HousePlus size={21} />
              </div>
              <div>
                <h2 className="font-bold text-white">Visa fliken Smarthem</h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
                  Aktivera eller dölj smarthemmet i dashboardens huvudmeny.
                  Smarthem är dold som standard. Sparade rum och enheter påverkas inte.
                </p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-label="Visa fliken Smarthem"
              aria-checked={settings.showHemmet3DTab}
              onClick={() => {
                setSettings((current) => ({
                  ...current,
                  showHemmet3DTab: !current.showHemmet3DTab,
                  defaultTab: current.showHemmet3DTab && current.defaultTab === "hemmet3d" ? "home" : current.defaultTab,
                }));
                setSuccessMessage(null);
              }}
              className={[
                "relative h-8 w-14 shrink-0 rounded-full border transition",
                settings.showHemmet3DTab ? "border-blue-400/40 bg-blue-500" : "border-white/10 bg-slate-700",
              ].join(" ")}
            >
              <span className={[
                "absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-transform",
                settings.showHemmet3DTab ? "translate-x-7" : "translate-x-1",
              ].join(" ")} />
            </button>
          </div>
        </section>

        {/* SCHOOL */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <div className="flex items-start gap-3 sm:gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-slate-200 sm:h-11 sm:w-11">
              <School size={21} />
            </div>

            <div className="min-w-0 flex-1">
              <h2 className="font-bold text-white">
                Skola
              </h2>

              <p className="mt-1 text-sm leading-6 text-slate-400">
                Ange vilken matsedel som ska visas i Skollunch-widgeten.
              </p>

              <div className="mt-4 max-w-3xl">
                <label
                  htmlFor="school-lunch-url"
                  className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500"
                >
                  Länk till matsedel
                </label>

                <input
                  id="school-lunch-url"
                  type="url"
                  value={settings.schoolLunchUrl}
                  onChange={(event) => {
                    setSettings((current) => ({
                      ...current,
                      schoolLunchUrl: event.target.value,
                    }));

                    setSuccessMessage(null);
                  }}
                  className="min-h-12 w-full rounded-2xl border border-white/10 bg-slate-950/40 px-4 text-sm text-white outline-none transition placeholder:text-slate-600 focus:border-blue-400/50 focus:ring-2 focus:ring-blue-500/20"
                  placeholder="https://skolmaten.se/api/4/rss/week/..."
                />

                <p className="mt-2 text-xs leading-5 text-slate-500">
                  Klistra in RSS-länken från Skolmaten. Lämna fältet tomt om ingen matsedel ska användas.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ADMIN BUTTON */}
        <section className="mt-4 rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur-xl sm:mt-5 sm:p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3 sm:gap-4">
              <div
                className={[
                  "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl",
                  settings.showAdminButton
                    ? "bg-emerald-500/15 text-emerald-300"
                    : "bg-white/10 text-slate-400",
                ].join(" ")}
              >
                {settings.showAdminButton ? (
                  <Eye size={21} />
                ) : (
                  <EyeOff size={21} />
                )}
              </div>

              <div>
                <h2 className="font-bold text-white">
                  Visa Admin-knappen
                </h2>

                <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
                  Bestämmer om kugghjulet för Admin ska
                  visas bredvid dashboardens huvudflikar.
                </p>
              </div>
            </div>

            <button
              type="button"
              role="switch"
              aria-checked={settings.showAdminButton}
              onClick={() => {
                setSettings((current) => ({
                  ...current,
                  showAdminButton:
                    !current.showAdminButton,
                }));

                setSuccessMessage(null);
              }}
              className={[
                "relative h-8 w-14 shrink-0 rounded-full border transition",
                settings.showAdminButton
                  ? "border-blue-400/40 bg-blue-500"
                  : "border-white/10 bg-slate-700",
              ].join(" ")}
            >
              <span
                className={[
                  "absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-transform",
                  settings.showAdminButton
                    ? "translate-x-7"
                    : "translate-x-1",
                ].join(" ")}
              />
            </button>
          </div>
        </section>

        {/* STATUS */}
        {error && (
          <div className="mt-4 rounded-2xl border border-red-300/15 bg-red-400/[0.06] px-4 py-3 text-sm text-red-200 sm:mt-5">
            {error}
          </div>
        )}

        {successMessage && (
          <div className="mt-4 rounded-2xl border border-emerald-300/15 bg-emerald-400/[0.06] px-4 py-3 text-sm text-emerald-200 sm:mt-5">
            {successMessage}
          </div>
        )}

        {/* ACTIONS */}
        <div className="mt-4 flex flex-col-reverse gap-3 rounded-3xl border border-white/10 bg-white/10 p-4 sm:mt-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm font-semibold text-white">
              {hasChanges
                ? "Du har osparade ändringar"
                : "Alla ändringar är sparade"}
            </p>

            <p className="mt-1 text-xs text-slate-500">
              Inställningarna lagras centralt i Supabase.
            </p>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              onClick={resetChanges}
              disabled={!hasChanges || isSaving}
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.05] px-4 text-sm font-semibold text-slate-300 transition hover:bg-white/10 hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
            >
              <RotateCcw size={17} />
              Ångra ändringar
            </button>

            <button
              type="button"
              onClick={() => void saveSettings()}
              disabled={!hasChanges || isSaving}
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-blue-500 px-5 text-sm font-semibold text-white shadow-lg shadow-blue-950/30 transition hover:bg-blue-400 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {isSaving ? (
                <LoaderCircle
                  size={17}
                  className="animate-spin"
                />
              ) : (
                <Save size={17} />
              )}

              {isSaving
                ? "Sparar…"
                : "Spara ändringar"}
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}